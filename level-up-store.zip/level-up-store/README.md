# LEVEL UP STORE

Site estático responsivo da LEVEL UP STORE, com tema gamer preto e roxo neon.

## Arquivos
- `index.html` — conteúdo e estrutura da página
- `style.css` — design responsivo
- `script.js` — menu mobile, filtro de catálogo e ano automático

## Antes de publicar
1. Abra `index.html`.
2. No trecho de contato, substitua `https://wa.me/` pelo link do WhatsApp da loja. Exemplo: `https://wa.me/55DDDNUMERO` (somente números após o domínio).
3. Substitua `https://www.instagram.com/` pelo link do perfil da loja.
4. Edite os textos de exemplo do catálogo. Os cards não são ofertas reais e não processam pagamentos.
5. Use apenas imagens e marcas que você tem permissão para usar e confira as regras oficiais dos jogos para qualquer produto ou serviço anunciado.

## Publicar gratuitamente no GitHub + Cloudflare Pages
1. Entre em https://github.com/ e crie uma conta ou entre na sua.
2. Crie um repositório público chamado `level-up-store`.
3. Envie `index.html`, `style.css`, `script.js` e `README.md` para o repositório (Add file → Upload files).
4. Entre em https://pages.cloudflare.com/ e faça login/cadastro.
5. Crie um projeto Pages conectado ao GitHub e escolha o repositório `level-up-store`.
6. Como é um site estático puro, deixe o comando de build vazio e use ` / ` como diretório de saída se a interface pedir (em geral, `.` é aceito para a raiz do repositório).
7. Inicie o deploy e aguarde o endereço `*.pages.dev`.

A interface do Cloudflare pode mudar. Não é necessário comprar um domínio personalizado para usar o endereço gratuito `pages.dev`.
